import java.util.Scanner;

    public class DCMotorSpeedCalculator {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Taking user input
            System.out.print("Enter Voltage (V): ");
            double voltage = scanner.nextDouble();

            System.out.print("Enter Back EMF (V): ");
            double backEMF = scanner.nextDouble();

            System.out.print("Enter Motor Constant (V/rpm): ");
            double motorConstant = scanner.nextDouble();

            // Input validation
            if (motorConstant <= 0) {
                System.out.println("Error: Motor constant must be greater than zero.");
            } else if (voltage < 0 || backEMF < 0) {
                System.out.println("Error: Voltage and Back EMF cannot be negative.");
            } else if (voltage <= backEMF) {
                System.out.println("Error: Voltage must be greater than Back EMF for the motor to run.");
            } else {
                // Calculate speed in RPM
                double speed = (voltage - backEMF) / motorConstant;
                System.out.printf("The speed of the DC motor is: %.2f RPM\n", speed);
            }

            scanner.close();
        }
    }

