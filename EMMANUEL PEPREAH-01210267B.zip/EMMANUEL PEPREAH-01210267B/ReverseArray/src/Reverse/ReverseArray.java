package Reverse;

import java.util.Arrays;

public class ReverseArray {
    public static void main(String[] args) {
        // Original array
        int[] array = {1, 2, 3, 4, 5};

        // Print the original array
        System.out.println("Original Array: " + Arrays.toString(array));

        // Reverse the array
        int[] reversedArray = reverse(array);

        // Print the reversed array
        System.out.println("Reversed Array: " + Arrays.toString(reversedArray));
    }

    // Method to reverse the array
    public static int[] reverse(int[] array) {
        int length = array.length;
        int[] reversedArray = new int[length];

        for (int i = 0; i < length; i++) {
            reversedArray[i] = array[length - 1 - i];
        }

        return reversedArray;
    }
}
